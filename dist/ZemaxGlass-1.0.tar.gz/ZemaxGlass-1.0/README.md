zemaxglass
==========

A suite of utilities of analyzing optical glasses using the Zemax glass library, released as open source under the MIT/X license.

For instructions and examples on how to use the code, see the user guide PDF.